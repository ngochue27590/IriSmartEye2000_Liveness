#include "pch.h";
#include "Iddk2000Apis.h";
#include "IriLivenessBase.h"
#include <string>
#include <iostream>;
using namespace std;
#define TEST_productID "" 
#define TEST_productName ""
#define TEST_isBinocular ""
#define TEST_serialNumber ""
#define TEST_propertyFlag ""
#define TEST_kernelVersion ""
#define TEST_kernelRevision ""
#define TEST_deviceFeatures ""

TEST(IddkGetDeviceInfoTest, ReturnsIDDK_OK) {
    cout << "TC06_01_001" << endl;
    int nDeviceCnt = 0;
    const char** ppDeviceDescs = nullptr;
    IddkResult scanDeviceResult = Iddk_ScanDevices(&ppDeviceDescs, &nDeviceCnt);
    EXPECT_EQ(scanDeviceResult, IDDK_OK);

    HIRICAMM hDevice;
    IddkResult openDeviceResult = Iddk_OpenDevice(ppDeviceDescs[0], &hDevice);
    EXPECT_EQ(openDeviceResult, IDDK_OK);

    IddkDeviceInfo deviceInfo;
    IddkResult result = Iddk_GetDeviceInfo(hDevice, &deviceInfo);
    EXPECT_EQ(result, IDDK_OK);
    EXPECT_EQ(deviceInfo.productID,TEST_productID);
    EXPECT_EQ(deviceInfo.productName, TEST_productName);
    EXPECT_EQ(deviceInfo.isBinocular, TEST_isBinocular);
    EXPECT_EQ(deviceInfo.serialNumber, TEST_serialNumber);
    EXPECT_EQ(deviceInfo.propertyFlag, TEST_propertyFlag);
    EXPECT_EQ(deviceInfo.kernelVersion, TEST_kernelVersion);
    EXPECT_EQ(deviceInfo.kernelRevision, TEST_kernelRevision);
    EXPECT_EQ(deviceInfo.deviceFeatures, TEST_deviceFeatures);
}

TEST(IddkGetDeviceInfoTest, ReturnsIDDK_INVALID_PARAMETER) {
    cout << "TC06_02_001" << endl;
    int nDeviceCnt = 0;
    const char** ppDeviceDescs = nullptr;
    IddkResult scanDeviceResult = Iddk_ScanDevices(&ppDeviceDescs, NULL);
    EXPECT_EQ(scanDeviceResult, IDDK_INVALID_PARAMETER);

    HIRICAMM hDevice;
    IddkResult openDeviceResult = Iddk_OpenDevice(ppDeviceDescs[0], &hDevice);
    EXPECT_EQ(openDeviceResult, IDDK_INVALID_PARAMETER);

    IddkDeviceInfo deviceInfo;
    IddkResult result = Iddk_GetDeviceInfo(&hDevice, &deviceInfo);
    EXPECT_EQ(result, IDDK_INVALID_PARAMETER);
}
//
TEST(IddkGetDeviceInfoTest, ReturnsIDDK_INVALID_HANDLE) {
    cout << "TC07_03_001" << endl;

    HIRICAMM invalidHandle = "invalid handle";
    IddkDeviceInfo deviceInfo;
    IddkResult result = Iddk_GetDeviceInfo(invalidHandle, &deviceInfo);
    EXPECT_EQ(result, IDDK_INVALID_HANDLE);
}
