#include "pch.h"
#include "Iddk2000Apis.h"
#include <iostream>
#include <cstring> 
using namespace std;

TEST(testGetSDKdes, SDKdes)
{
	cout << "Test: TC2_01_001.\n";
	char buffer[256];
	int size = 256;
	IddkResult result = Iddk_GetSdkDescription(buffer, &size);
	EXPECT_EQ(result, IDDK_OK);
}

TEST(testGetSDKdes, SDKdes1)
{
	cout << "Test: TC2_01_002.\n";
	char *buffer = nullptr;
	int size = 1;
	EXPECT_EQ(Iddk_GetSdkDescription(buffer, &size), IDDK_INVALID_PARAMETER);
}

TEST(testGetSDKdes, SDKdes3)
{
	cout << "Test: TC2_01_003.\n";
	char buffer[25];
	int size = 16;
	EXPECT_EQ(Iddk_GetSdkDescription(buffer, &size), IDDK_NOT_ENOUGH_BUFFER);
}
