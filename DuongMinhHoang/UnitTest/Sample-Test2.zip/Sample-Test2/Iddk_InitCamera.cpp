#include "pch.h";
#include "Iddk2000Apis.h";
#include <string>
#include <iostream>;
using namespace std;
TEST(IddkCameraTests, InitCameraSuccess) {
    cout << "TC04_01_001" << endl;
    int nDeviceCnt = 0;
    const char** ppDeviceDescs = nullptr;
    IddkResult scanDeviceResult = Iddk_ScanDevices(&ppDeviceDescs, &nDeviceCnt);
    EXPECT_EQ(scanDeviceResult, IDDK_OK);

    HIRICAMM hDevice;
    IddkResult openDeviceResult = Iddk_OpenDevice(ppDeviceDescs[0], &hDevice);
    EXPECT_EQ(openDeviceResult, IDDK_OK);
    HIRICAMM hDevice;
    int pnImageWidth = 640, pnImageHeight = 480;
    IddkResult result = Iddk_InitCamera(hDevice, &pnImageWidth, &pnImageHeight);
    EXPECT_EQ(result, IDDK_OK);
}

TEST(IddkCameraTests, InitCameraInvalidParameter) {
    cout << "TC04_02_001" << endl;
    int nDeviceCnt = 0;
    const char** ppDeviceDescs = nullptr;
    IddkResult scanDeviceResult = Iddk_ScanDevices(&ppDeviceDescs, &nDeviceCnt);
    EXPECT_EQ(scanDeviceResult, IDDK_INVALID_PARAMETER);

    HIRICAMM hDevice;
    IddkResult openDeviceResult = Iddk_OpenDevice(ppDeviceDescs[0], &hDevice);
    EXPECT_EQ(openDeviceResult, IDDK_INVALID_PARAMETER);
    HIRICAMM hDevice;
    HIRICAMM hDevice;
    int pnImageWidth = 640, pnImageHeight = 480;
    IddkResult result = Iddk_InitCamera(hDevice, &pnImageWidth, &pnImageHeight);
    EXPECT_EQ(result, IDDK_INVALID_PARAMETER);
}

