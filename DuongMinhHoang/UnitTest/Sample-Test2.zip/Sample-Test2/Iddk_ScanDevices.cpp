#include "pch.h";
#include "Iddk2000Apis.h";
#include <iostream>;
using namespace std;
TEST(ScanDevices, sdkScan)
{
	cout << "TEST TC3_01_001.\n";
	int pnDevices = 1;
	EXPECT_EQ(Iddk_ScanDevices(nullptr, &pnDevices), IDDK_INVALID_PARAMETER);
}

TEST(ScanDevices, sdkScan1)
{
	cout << "TEST TC3_01_002.\n";
	const char** ppDeviceDescs;
	int nDevices;
	EXPECT_EQ(Iddk_ScanDevices(&ppDeviceDescs, &nDevices), IDDK_OK);
}

TEST(ScanDevices, sdkScan2) {
	cout << "TEST TC3_01_003.\n";
	const char** ppDeviceDescs;
	int nDevices = 0;
	EXPECT_EQ(Iddk_ScanDevices(&ppDeviceDescs, &nDevices), IDDK_DEVICE_NOT_FOUND);
}

TEST(ScanDevices, sdkScan3) {
	cout << "TEST TC3_01_004.\n";
	const char** ppDeviceDescs;
	int nDevices = 0;
	EXPECT_EQ(Iddk_ScanDevices(&ppDeviceDescs, &nDevices), IDDK_INVALID_HANDLE);
}

