﻿#include "pch.h";
#include "Iddk2000Apis.h";
#include "IriLivenessBase.h"
#include <string>
#include <iostream>;
using namespace std;

TEST(IddkCloseDeviceTest, ReturnsIDDK_OK) {
    cout << "TC07_01_001" << endl;
    int nDeviceCnt = 0;
    const char** ppDeviceDescs = nullptr;
    IddkResult scanDeviceResult = Iddk_ScanDevices(&ppDeviceDescs, &nDeviceCnt);
    EXPECT_EQ(scanDeviceResult, IDDK_OK);

    HIRICAMM hDevice;
    IddkResult openDeviceResult = Iddk_OpenDevice(ppDeviceDescs[0], &hDevice);
    EXPECT_EQ(openDeviceResult, IDDK_OK);

    IddkResult result = Iddk_CloseDevice(hDevice);
    EXPECT_EQ(result, IDDK_OK);
    EXPECT_EQ(hDevice, NULL);
}
TEST(IddkCloseDeviceTest, ReturnsIDDK_INVALID_PARAMETER) {
    cout << "TC07_02_001" << endl;
    HIRICAMM hDevice = NULL; /*hDevice is NULL*/
    IddkResult result = Iddk_CloseDevice(hDevice);
    EXPECT_EQ(result, IDDK_INVALID_PARAMETER);
}

TEST(IddkCloseDeviceTest, ReturnsIDDK_INVALID_HANDLE) {
    cout << "TC07_02_001" << endl;
    HIRICAMM hDevice = "InvalidDevice";
    IddkResult result = Iddk_CloseDevice(hDevice);
    EXPECT_EQ(result, IDDK_INVALID_HANDLE);
}