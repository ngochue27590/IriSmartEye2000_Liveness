﻿#include "pch.h";
#include "Iddk2000Apis.h";
#include "IriLivenessBase.h"
#include <string>
#include <iostream>;
using namespace std;
TEST(testGetSDKdes, SDKdes3)
{
	cout << "Test: TC2_01_003.\n";
	char buffer[25];
	int size = 26;
	EXPECT_EQ(Iddk_GetSdkDescription(buffer, &size), IDDK_NOT_ENOUGH_BUFFER);
}







