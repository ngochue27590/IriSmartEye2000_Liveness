#include "pch.h";
#include "Iddk2000Apis.h";
#include <iostream>;
using namespace std;

TEST(IddkOpenDeviceTest, InvalidParameter) {
    cout << "Test: TC4_01_001.\n";
    int nDeviceCnt = 0;
    const char** ppDeviceDescs = nullptr;
    IddkResult scanDeviceResult = Iddk_ScanDevices(&ppDeviceDescs, &nDeviceCnt);
    EXPECT_EQ(scanDeviceResult, IDDK_INVALID_PARAMETER);
    HIRICAMM hDevice;
    IddkResult openDeviceResult = Iddk_OpenDevice(ppDeviceDescs[0], &hDevice);
    EXPECT_EQ(openDeviceResult, IDDK_INVALID_PARAMETER);
}


TEST(IddkOpenDeviceTest, DeviceNotFound) {
    cout << "Test: TC4_02_001.\n";
    int nDeviceCnt = 0;
    const char** ppDeviceDescs;
    const char* devicename = "IriShield 123";
    ppDeviceDescs = &devicename;
    IddkResult scanDeviceResult = Iddk_ScanDevices(&ppDeviceDescs, &nDeviceCnt);
    EXPECT_EQ(scanDeviceResult, IDDK_OK);
    HIRICAMM hDevice;
    IddkResult openDeviceResult = Iddk_OpenDevice(ppDeviceDescs[0], &hDevice);
    EXPECT_EQ(openDeviceResult, IDDK_DEVICE_NOT_FOUND);
}


TEST(IddkOpenDeviceTest, DeviceOpenFailed) {
    cout << "Test: TC4_04_001.\n";
    int nDeviceCnt = 0;
    const char** ppDeviceDescs ;
    const char* devicename = "IriShield 123";
    ppDeviceDescs = &devicename;
    IddkResult scanDeviceResult = Iddk_ScanDevices(&ppDeviceDescs, &nDeviceCnt);
    EXPECT_EQ(scanDeviceResult, IDDK_OK);
    HIRICAMM hDevice;
    IddkResult result = Iddk_OpenDevice(ppDeviceDescs[0], &hDevice);
    EXPECT_EQ(result, IDDK_DEVICE_OPEN_FAILED);
}


TEST(IddkOpenDeviceTest, TooManyOpenDevices) {
    cout << "Test: TC4_05_001.\n";
    int nDeviceCnt = 10;
    const char** ppDeviceDescs = nullptr;
    IddkResult scanDeviceResult = Iddk_ScanDevices(&ppDeviceDescs, &nDeviceCnt);
    EXPECT_EQ(scanDeviceResult, IDDK_OK);
    HIRICAMM hDevice;
    IddkResult result = Iddk_OpenDevice(ppDeviceDescs[10], &hDevice);
    EXPECT_EQ(result, IDDK_TOO_MANY_OPEN_DEVICES);
}


TEST(IddkOpenDeviceTest, Success) {
    cout << "Test: TC4_06_001.\n";
    int nDeviceCnt = 0;
    const char** ppDeviceDescs = nullptr;
    IddkResult scanDeviceResult = Iddk_ScanDevices(&ppDeviceDescs, &nDeviceCnt);
    EXPECT_EQ(scanDeviceResult, IDDK_OK);
    HIRICAMM hDevice;
    IddkResult openDeviceResult = Iddk_OpenDevice(ppDeviceDescs[0], &hDevice);
    EXPECT_EQ(openDeviceResult, IDDK_OK);
}